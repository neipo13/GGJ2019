﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GGJ2019.Constants
{
    public enum RenderLayers
    {
        UI,
        Foreground,
        Object,
        Decorative,
        Background,
        WayBack
    }

    //public static int GetLayer(RenderLayers layer)
    //{
    //    return (int)layer;
    //}
}
